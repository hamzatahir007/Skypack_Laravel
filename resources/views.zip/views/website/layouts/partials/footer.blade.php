<!--====== FOOTER PART START ======-->

    <footer class="footer_area">
        <div class="footer_widget pt-70 pb-120">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="footer_link mt-45">
                            <h5 class="footer_title">Company</h5>
                            <ul class="link">
                                <li><a href="#">Home</a></li>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Our Factories</a></li>
                                <li><a href="#">Mission and Strategy</a></li>
                                <li><a href="#">Profitable Actions</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="footer_link mt-45">
                            <h5 class="footer_title">Deliver Fast</h5>
                            <ul class="link">
                                <li><a href="#">Packing TIps</a></li>
                                <li><a href="#">Send and Receive Quickly</a></li>
                                <li><a href="#">Membership</a></li>
                                <li><a href="#">Banner Advertising</a></li>
                                <li><a href="#">Promote Your Ad</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="footer_link mt-45">
                            <h5 class="footer_title">Information</h5>
                            <ul class="link">
                                <li><a href="#">Company &amp; Contact Info</a></li>
                                <li><a href="#">Blog &amp; Articles</a></li>
                                <li><a href="#">Sitemap</a></li>
                                <li><a href="#">Terms of Service</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="footer_link mt-45">
                            <h5 class="footer_title">Help &amp; Support</h5>
                            <ul class="link">
                                <li><a href="#">Live Chat</a></li>
                                <li><a href="#">FAQ</a></li>
                                <li><a href="#">How to Stay Safe</a></li>
                                <li><a href="#">Terms &amp; Conditions</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer_copyright pt-15 pb-30">
            <div class="container">
                <div class="footer_copyright_wrapper text-center d-sm-flex justify-content-between align-items-center">
                    <div class="copyright mt-15">
                        <p>© 2025 Lauggagelink Ltd. All rights reserved</p>
                    </div>
                    <div class="payment mt-15">
                        <ul>
                            <li><a href="#"><img  src="{{ asset('img/payment-method1.jpg') }}" alt="payment"></a></li>
                            <li><a href="#"><img  src="{{ asset('img/payment-method1.jpg') }}" alt="payment"></a></li>
                            <li><a href="#"><img  src="{{ asset('img/payment-method1.jpg') }}" alt="payment"></a></li>
                            <li><a href="#"><img  src="{{ asset('img/payment-method1.jpg') }}" alt="payment"></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>